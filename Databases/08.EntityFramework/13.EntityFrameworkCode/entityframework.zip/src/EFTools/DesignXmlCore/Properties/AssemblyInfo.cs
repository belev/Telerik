// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

using System;
using System.Reflection;

[assembly: AssemblyTitle("Microsoft.VisualStudio.Data.Tools.Design.XmlCore")]
[assembly: AssemblyDescription("Microsoft.VisualStudio.Data.Tools.Design.XmlCore.dll")]
[assembly: CLSCompliant(false)]
