// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Data.Entity.Design")]
[assembly: AssemblyDescription("Microsoft.Data.Entity.Design.dll")]
[assembly: CLSCompliant(false)]
[assembly: Guid("af5600cc-afa7-4835-8ab7-ad8c7d68235e")]
