define(function() {
   var ITEM_TYPES = Object.freeze({
       ACCESSORY: 'accessory',
       'SMART-PHONE': 'smart-phone',
       NOTEBOOK: 'notebook',
       PC: 'pc',
       TABLET: 'tablet'
   });

    return ITEM_TYPES;
});